package com.se.ipd;

public enum Response {
	COOPERATE, DEFECT
}
